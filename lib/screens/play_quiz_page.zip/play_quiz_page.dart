import 'dart:io';
import 'package:flutter/material.dart';
import '../models/quiz_question.dart';

class PlayQuizPage extends StatefulWidget {
  final List<QuizQuestion> questions;

  const PlayQuizPage({super.key, required this.questions});

  @override
  State<PlayQuizPage> createState() => _PlayQuizPageState();
}

class _PlayQuizPageState extends State<PlayQuizPage> {
  final Map<int, dynamic> _answers = {};

  void _submitQuiz() {
    int score = 0;
    int totalPoints = 0;

    for (int i = 0; i < widget.questions.length; i++) {
      final q = widget.questions[i];
      final userAnswer = _answers[i];
      totalPoints += q.points;

      if (q.correctSingleChoice != null &&
          userAnswer == q.correctSingleChoice) {
        score += q.points;
      }

      if (q.correctMultiChoices.isNotEmpty &&
          userAnswer is List<String> &&
          _listsEqual(userAnswer, q.correctMultiChoices)) {
        score += q.points;
      }

      if (q.correctParagraph != null &&
          userAnswer is String &&
          userAnswer.trim().toLowerCase() ==
              q.correctParagraph!.trim().toLowerCase()) {
        score += q.points;
      }
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Quiz Result"),
        content: Text("Your Score: $score / $totalPoints"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          )
        ],
      ),
    );
  }

  bool _listsEqual(List<String> a, List<String> b) {
    final setA = a.toSet();
    final setB = b.toSet();
    return setA.length == setB.length && setA.containsAll(setB);
  }

  @override
  Widget build(BuildContext context) {
    if (widget.questions.isEmpty) {
      return const Scaffold(
        body: Center(child: Text("No quiz questions available")),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Play Quiz")),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: widget.questions.length,
        itemBuilder: (context, index) {
          final q = widget.questions[index];

          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (q.imagePath != null)
                    Image.file(File(q.imagePath!), height: 150),
                  Text(
                    "${index + 1}. ${q.question}",
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  if (q.singleChoice != null) ...[
                    ...["Option A", "Option B", "Option C", "Option D"].map(
                      (opt) => RadioListTile<String>(
                        title: Text(opt),
                        value: opt,
                        groupValue: _answers[index] as String?,
                        onChanged: (val) {
                          setState(() {
                            _answers[index] = val;
                          });
                        },
                      ),
                    ),
                  ],
                  if (q.multiChoices.isNotEmpty) ...[
                    ...["Option A", "Option B", "Option C", "Option D"].map(
                      (opt) => CheckboxListTile(
                        title: Text(opt),
                        value:
                            (_answers[index] as List<String>?)?.contains(opt) ??
                                false,
                        onChanged: (checked) {
                          setState(() {
                            final current =
                                (_answers[index] as List<String>?) ?? [];
                            if (checked == true) {
                              current.add(opt);
                            } else {
                              current.remove(opt);
                            }
                            _answers[index] = current;
                          });
                        },
                      ),
                    ),
                  ],
                  if (q.paragraphAnswer != null)
                    TextField(
                      decoration: const InputDecoration(
                        hintText: "Write your answer...",
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                      onChanged: (val) {
                        _answers[index] = val;
                      },
                    ),
                ],
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(12),
        child: ElevatedButton.icon(
          onPressed: _submitQuiz,
          icon: const Icon(Icons.check),
          label: const Text("Submit Quiz"),
        ),
      ),
    );
  }
}
